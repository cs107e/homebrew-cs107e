/* Generated automatically. */
static const char configuration_arguments[] = "/private/tmp/riscv-gnu-toolchain-20231206-38982-ynb243/gcc/configure --target=riscv64-unknown-elf --prefix=@@HOMEBREW_CELLAR@@/riscv-gnu-toolchain/main --disable-shared --disable-threads --enable-languages=c,c++ --with-pkgversion=gc891d8dc2-dirty --with-system-zlib --enable-tls --with-newlib --with-sysroot=@@HOMEBREW_CELLAR@@/riscv-gnu-toolchain/main/riscv64-unknown-elf --with-native-system-header-dir=/include --disable-libmudflap --disable-libssp --disable-libquadmath --disable-libgomp --disable-nls --disable-tm-clone-registry --src=.././gcc --enable-multilib --with-abi=lp64d --with-arch=rv64imafdc --with-tune=rocket --with-isa-spec=20191213 'CFLAGS_FOR_TARGET=-Os    -mcmodel=medany' 'CXXFLAGS_FOR_TARGET=-Os    -mcmodel=medany'";
static const char thread_model[] = "single";

static const struct {
  const char *name, *value;
} configure_default_options[] = { { "abi", "lp64d" }, { "arch", "rv64imafdc_zicsr" }, { "tune", "rocket" }, { "isa_spec", "20191213" } };
